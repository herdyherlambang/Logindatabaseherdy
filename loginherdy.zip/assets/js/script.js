// event pada saat link di klik

$('.page-scroll').on('click', function(){

	// ambil isi href
	var tujuan = $(this).attr('href');
	console.log(href)

	// tangkap elemen
	var elemenTujuan = $(tujua)

});